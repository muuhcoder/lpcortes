import React from 'react';
import { Star, ShieldCheck, Award, Users, Scissors } from 'lucide-react';
import { BARBERSHOP_DATA } from '../data/barbershop';

export const About: React.FC = () => {
  return (
    <section id="sobre" className="py-24 sm:py-32 relative bg-[#0A0F1D] overflow-hidden">
      
      {/* Decorative ambient lighting */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-[#D4AF37]/5 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Main Editorial Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center mb-24">
          
          {/* Left Column: Authentic Barbershop Craftsmanship Image */}
          <div className="lg:col-span-6 relative">
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              
              {/* Backing gold border accent */}
              <div className="absolute -inset-4 border border-[#D4AF37]/25 rounded-md -translate-x-3 -translate-y-3 hidden sm:block" />
              
              <div className="relative rounded-md overflow-hidden bg-[#0F172A] border border-[#D4AF37]/40 shadow-2xl aspect-[4/5]">
                <img
                  src="https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&w=1200&q=85"
                  alt="Barbeiro profissional da LP Cortes executando acabamento com precisão milimétrica"
                  className="w-full h-full object-cover object-center"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0F1D] via-transparent to-transparent opacity-70" />
                
                {/* Floating experience badge */}
                <div className="absolute top-6 left-6 p-4 rounded-sm bg-[#0A0F1D]/90 backdrop-blur-md border border-[#D4AF37]/40 shadow-xl">
                  <div className="flex items-center gap-3">
                    <Award className="w-8 h-8 text-[#D4AF37]" />
                    <div>
                      <span className="block font-heading text-xl font-bold text-white leading-tight">
                        Tradição & Maestria
                      </span>
                      <span className="text-[11px] text-[#D4AF37] uppercase tracking-widest font-semibold">
                        Desde 2011 em Birigui
                      </span>
                    </div>
                  </div>
                </div>

                {/* Rating badge bottom right */}
                <div className="absolute bottom-6 right-6 p-3.5 rounded-sm bg-[#0A0F1D]/90 backdrop-blur-md border border-[#D4AF37]/40">
                  <div className="flex items-center gap-1.5 text-[#D4AF37] mb-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#D4AF37]" />
                    ))}
                  </div>
                  <div className="text-xs text-slate-200 font-semibold text-right">
                    Nota 4.9 de Avaliação
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Manifesto and Philosophy */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            
            <div className="inline-flex items-center gap-2 self-start px-3 py-1 rounded-full border border-[#D4AF37]/40 bg-[#0F172A] mb-5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#D4AF37]">
                Sobre a LP Cortes
              </span>
            </div>

            <h2 className="font-heading text-4xl sm:text-5xl lg:text-5xl font-bold text-white tracking-tight leading-[1.1] mb-6">
              Onde a tradição encontra a excelência contemporânea.
            </h2>

            <div className="space-y-4 text-slate-300 font-light text-base sm:text-lg leading-relaxed mb-8">
              <p>
                A LP Cortes nasceu com uma missão clara: elevar o momento de cuidar da aparência masculina a uma experiência de respeito, relaxamento e identidade.
              </p>
              <p>
                Nossos barbeiros dominam desde o clássico corte executivo na tesoura até os degradês e cortes mais modernos da atualidade, combinando visagismo apurado ao ritual relaxante da toalha aquecida e navalha esterilizada.
              </p>
            </div>

            <div className="p-4 rounded-sm bg-[#0F172A]/80 border-l-2 border-[#D4AF37] mb-6">
              <p className="text-sm italic text-slate-200 font-medium">
                "Não vendemos apenas cortes de cabelo. Lapidamos a confiança do homem para que ele ocupe qualquer espaço com imponência."
              </p>
              <span className="block text-xs uppercase tracking-wider text-[#D4AF37] font-semibold mt-2">
                — Fundador, LP Cortes
              </span>
            </div>

          </div>

        </div>

        {/* 4 Stats Grid - Exactly requested in the brief */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 pt-12 border-t border-[#D4AF37]/20">
          {BARBERSHOP_DATA.stats.map((stat, index) => (
            <div
              key={index}
              className="p-6 sm:p-8 rounded-md bg-[#0F172A] border border-[#D4AF37]/20 hover:border-[#D4AF37]/50 transition-colors text-center group"
            >
              <div className="font-heading text-4xl sm:text-5xl lg:text-6xl font-black text-[#D4AF37] tracking-tight mb-2 group-hover:scale-105 transition-transform duration-300">
                {stat.value}
              </div>
              <div className="font-heading text-base sm:text-lg font-bold text-white mb-1">
                {stat.label}
              </div>
              <div className="text-xs text-slate-400 font-light">
                {stat.detail}
              </div>
            </div>
          ))}
        </div>

        {/* Client Testimonials Quote Strip */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-6">
          {BARBERSHOP_DATA.testimonials.map((t, idx) => (
            <div
              key={idx}
              className="p-6 rounded-md bg-[#0F172A]/60 border border-slate-800 hover:border-[#D4AF37]/30 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-1 text-[#D4AF37] mb-3">
                  {[...Array(t.stars)].map((_, s) => (
                    <Star key={s} className="w-3.5 h-3.5 fill-[#D4AF37]" />
                  ))}
                </div>
                <p className="text-sm text-slate-300 font-light italic leading-relaxed mb-4">
                  "{t.comment}"
                </p>
              </div>
              <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-800">
                <span className="font-semibold text-white">{t.name}</span>
                <span className="text-slate-400">{t.city}</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
