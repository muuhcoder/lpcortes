import React, { useState } from 'react';
import { MapPin, Phone, MessageSquare, Clock, Send, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { BARBERSHOP_DATA } from '../data/barbershop';

export const Contact: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [subject, setSubject] = useState('Dúvida sobre Agendamento');
  const [message, setMessage] = useState('');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const formattedMessage = `*MENSAGEM VIA SITE - LP CORTES*\n\n` +
      `👤 *Nome:* ${name.trim()}\n` +
      `📱 *Contato:* ${phone.trim() || 'Não informado'}\n` +
      `📌 *Assunto:* ${subject}\n\n` +
      `💬 *Mensagem:*\n${message.trim() || 'Gostaria de mais informações sobre os serviços da barbearia.'}`;

    const url = `https://wa.me/${BARBERSHOP_DATA.phone.raw}?text=${encodeURIComponent(formattedMessage)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-24 sm:py-32 relative bg-[#0A0F1D] border-t border-[#D4AF37]/15">
      
      {/* Ambient background blur */}
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#D4AF37]/5 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-[#D4AF37]/40 bg-[#0F172A] mb-4">
            <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#D4AF37]">
              Localização & Contato
            </span>
          </div>

          <h2 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight mb-4">
            Venha nos Visitar
          </h2>

          <p className="text-base sm:text-lg text-slate-400 font-light">
            Ambiente climatizado, atendimento com horário marcado e estacionamento facilitado em Birigui.
          </p>
        </div>

        {/* Contact Split Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start mb-20">
          
          {/* Left Column: Direct info cards & Google Maps */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Address Card */}
            <div className="p-6 rounded-md bg-[#0F172A] border border-[#D4AF37]/25 hover:border-[#D4AF37]/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-heading text-lg font-bold text-white mb-1">
                    Endereço
                  </h3>
                  <p className="text-sm text-slate-300 leading-relaxed mb-3">
                    {BARBERSHOP_DATA.address.full}
                  </p>
                  <a
                    href={BARBERSHOP_DATA.address.mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#D4AF37] hover:underline"
                  >
                    <span>Abrir rota no Google Maps</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>

            {/* Phone & WhatsApp Card */}
            <div className="p-6 rounded-md bg-[#0F172A] border border-[#D4AF37]/25 hover:border-[#D4AF37]/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-heading text-lg font-bold text-white mb-1">
                    Telefone & WhatsApp
                  </h3>
                  <p className="text-xl font-heading font-bold text-[#D4AF37] mb-3">
                    {BARBERSHOP_DATA.phone.display}
                  </p>
                  <a
                    href={BARBERSHOP_DATA.phone.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 w-full py-2.5 px-4 text-xs font-bold uppercase tracking-wider text-[#0F172A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89228] hover:from-white hover:to-[#D4AF37] rounded-sm transition-all"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Chamar no WhatsApp</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Hours card */}
            <div className="p-6 rounded-md bg-[#0F172A] border border-slate-800">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded bg-slate-800/80 text-slate-300 shrink-0">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-heading text-lg font-bold text-white mb-2">
                    Horário de Atendimento
                  </h3>
                  <div className="space-y-1 text-xs text-slate-300">
                    <p className="flex justify-between gap-4"><span className="text-slate-400">Terça a Sexta:</span> <span className="font-medium text-white">09:00 às 20:00</span></p>
                    <p className="flex justify-between gap-4"><span className="text-slate-400">Sábado:</span> <span className="font-medium text-white">08:30 às 19:30</span></p>
                    <p className="flex justify-between gap-4"><span className="text-slate-400">Domingo e Segunda:</span> <span className="text-slate-500">Fechado</span></p>
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Fast Contact Form */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-md bg-[#0F172A] border border-[#D4AF37]/35 shadow-2xl relative">
              <h3 className="font-heading text-2xl sm:text-3xl font-bold text-white mb-2">
                Envie uma Mensagem Direta
              </h3>
              <p className="text-sm text-slate-400 mb-8 font-light">
                Preencha os campos abaixo para falar diretamente com nossa equipe no WhatsApp.
              </p>

              <form onSubmit={handleSendMessage} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                      Seu Nome *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Como podemos te chamar?"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-4 py-3 rounded bg-[#0A0F1D] border border-slate-700 text-white placeholder-slate-500 text-sm focus:border-[#D4AF37] focus:outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                      WhatsApp / Telefone
                    </label>
                    <input
                      type="tel"
                      placeholder="(18) 98801-9075"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-4 py-3 rounded bg-[#0A0F1D] border border-slate-700 text-white placeholder-slate-500 text-sm focus:border-[#D4AF37] focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                    Assunto
                  </label>
                  <select
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-4 py-3 rounded bg-[#0A0F1D] border border-slate-700 text-white text-sm focus:border-[#D4AF37] focus:outline-none transition-colors"
                  >
                    <option value="Dúvida sobre Agendamento">Dúvida sobre Agendamento</option>
                    <option value="Corte Masculino (R$ 60)">Corte Masculino (R$ 60)</option>
                    <option value="Barba Terapia (R$ 45)">Barba Terapia (R$ 45)</option>
                    <option value="Tratamento Capilar (R$ 80)">Tratamento Capilar (R$ 80)</option>
                    <option value="Combo LP Signature (R$ 95)">Combo LP Signature (R$ 95)</option>
                    <option value="Outras Informações">Outras Informações</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                    Mensagem
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Escreva sua dúvida, preferência de dia ou detalhe do corte..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-4 py-3 rounded bg-[#0A0F1D] border border-slate-700 text-white placeholder-slate-500 text-sm focus:border-[#D4AF37] focus:outline-none transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2.5 py-4 px-6 text-xs font-bold uppercase tracking-wider text-[#0F172A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89228] hover:from-white hover:to-[#D4AF37] rounded-sm transition-all duration-300 shadow-xl shadow-[#D4AF37]/20 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Enviar Mensagem via WhatsApp</span>
                </button>
              </form>
            </div>
          </div>

        </div>

        {/* Elegant FAQ Accordion */}
        <div className="max-w-3xl mx-auto pt-12 border-t border-slate-800">
          <h3 className="font-heading text-2xl sm:text-3xl font-bold text-white text-center mb-8">
            Perguntas Frequentes
          </h3>

          <div className="space-y-4">
            {BARBERSHOP_DATA.faqs.map((faq, index) => {
              const isOpen = expandedFaq === index;
              return (
                <div
                  key={index}
                  className="rounded-md bg-[#0F172A]/70 border border-slate-800 overflow-hidden transition-colors"
                >
                  <button
                    onClick={() => setExpandedFaq(isOpen ? null : index)}
                    className="w-full p-5 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-[#141C30]/50 transition-colors"
                  >
                    <span className="font-heading text-base sm:text-lg font-bold text-white">
                      {faq.q}
                    </span>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 text-[#D4AF37] shrink-0" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-sm text-slate-300 font-light leading-relaxed border-t border-slate-800/60">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};
