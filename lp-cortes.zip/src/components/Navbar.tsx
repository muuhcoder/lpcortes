import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Calendar, Clock, Scissors } from 'lucide-react';
import { BARBERSHOP_DATA } from '../data/barbershop';

interface NavbarProps {
  onOpenBooking: (serviceId?: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenBooking }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Sobre Nós', href: '#sobre' },
    { label: 'Galeria', href: '#galeria' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#0A0F1D]/90 backdrop-blur-md border-b border-[#D4AF37]/20 py-3 shadow-2xl shadow-black/60'
          : 'bg-gradient-to-b from-[#0A0F1D]/80 via-[#0A0F1D]/40 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <a
            href="#inicio"
            className="group flex items-center gap-3 transition-transform duration-300 hover:scale-[1.02]"
            aria-label="LP Cortes - Início"
          >
            <div className="w-10 h-10 rounded-sm border border-[#D4AF37]/60 bg-[#0F172A] flex items-center justify-center relative overflow-hidden group-hover:border-[#D4AF37] transition-colors">
              <span className="font-heading text-lg font-bold text-[#D4AF37] tracking-wider">LP</span>
              <div className="absolute inset-0 bg-[#D4AF37]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div className="flex flex-col">
              <span className="font-heading text-xl font-bold tracking-[0.18em] text-white uppercase group-hover:text-[#D4AF37] transition-colors leading-none">
                LP Cortes
              </span>
              <span className="text-[10px] tracking-[0.3em] text-[#D4AF37]/80 uppercase font-medium mt-1">
                Barbearia Premium
              </span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8" aria-label="Navegação principal">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium tracking-wide text-slate-300 hover:text-[#D4AF37] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#D4AF37] hover:after:w-full after:transition-all after:duration-300"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Actions */}
          <div className="hidden sm:flex items-center gap-4">
            <a
              href={`tel:${BARBERSHOP_DATA.phone.raw}`}
              className="flex items-center gap-2 text-xs font-semibold text-slate-300 hover:text-white transition-colors py-2 px-3 rounded border border-slate-700/60 hover:border-[#D4AF37]/40 bg-[#0F172A]/60"
            >
              <Phone className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="hidden lg:inline">{BARBERSHOP_DATA.phone.display}</span>
            </a>

            <button
              onClick={() => onOpenBooking()}
              className="relative inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-bold tracking-wider uppercase text-[#0F172A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89228] hover:from-white hover:via-[#F3E5AB] hover:to-[#D4AF37] rounded-sm transition-all duration-300 shadow-md shadow-[#D4AF37]/20 hover:shadow-lg hover:shadow-[#D4AF37]/30 hover:scale-[1.02] active:scale-[0.99] cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5 text-[#0F172A]" />
              <span>Agende seu Horário</span>
            </button>
          </div>

          {/* Mobile hamburger */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => onOpenBooking()}
              className="px-3 py-1.5 text-xs font-bold uppercase text-[#0F172A] bg-[#D4AF37] rounded-sm flex items-center gap-1.5"
            >
              <Calendar className="w-3 h-3" />
              <span>Agendar</span>
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-[#D4AF37] focus:outline-none"
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0A0F1D]/98 border-b border-[#D4AF37]/25 px-4 pt-4 pb-6 mt-3 backdrop-blur-xl animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-base font-medium tracking-wide text-slate-200 hover:text-[#D4AF37] transition-colors py-2 border-b border-slate-800/80"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2 flex flex-col gap-3">
              <a
                href={BARBERSHOP_DATA.phone.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 rounded-sm text-sm font-semibold text-slate-200 border border-[#D4AF37]/40 bg-[#0F172A]"
              >
                <Phone className="w-4 h-4 text-[#D4AF37]" />
                WhatsApp: {BARBERSHOP_DATA.phone.display}
              </a>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenBooking();
                }}
                className="w-full py-3 text-sm font-bold tracking-wider uppercase text-[#0F172A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89228] rounded-sm flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                Agendar Horário Online
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
