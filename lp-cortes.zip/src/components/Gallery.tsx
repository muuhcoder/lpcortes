import React, { useState } from 'react';
import { Camera, ZoomIn, Scissors } from 'lucide-react';
import { BARBERSHOP_DATA } from '../data/barbershop';

export const Gallery: React.FC = () => {
  const [activePhoto, setActivePhoto] = useState<string | null>(null);

  const galleryItems = [
    {
      title: "Degradê Americano & Fade Limpo",
      category: "Corte Moderno",
      image: "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&w=1000&q=85",
      span: "lg:col-span-7 lg:row-span-2"
    },
    {
      title: "Barboterapia com Toalha Quente",
      category: "Ritual Tradicional",
      image: "https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=900&q=85",
      span: "lg:col-span-5"
    },
    {
      title: "Tesoura Japonesa & Navalha",
      category: "Instrumentos Esterilizados",
      image: "https://images.unsplash.com/photo-1532710093739-9470acff878f?auto=format&fit=crop&w=900&q=85",
      span: "lg:col-span-5"
    },
    {
      title: "Ambiente LP Cortes Lounge",
      category: "Conforto & Sofisticação",
      image: "https://images.unsplash.com/photo-1512690459411-b9245aed614b?auto=format&fit=crop&w=1200&q=85",
      span: "lg:col-span-12"
    }
  ];

  return (
    <section id="galeria" className="py-24 sm:py-32 relative bg-[#0B1020] border-t border-[#D4AF37]/15">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#D4AF37]/40 bg-[#0F172A] mb-4">
              <Camera className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#D4AF37]">
                Portfólio Visual
              </span>
            </div>
            <h2 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight">
              A Arte em Detalhes
            </h2>
          </div>
          <p className="text-sm sm:text-base text-slate-400 max-w-md font-light">
            Cada cliente é tratado como uma tela única. Registros reais da nossa bancada, do ambiente e de transformações diárias.
          </p>
        </div>

        {/* Asymmetrical Editorial Mosaic Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 auto-rows-[300px]">
          {galleryItems.map((item, index) => (
            <div
              key={index}
              onClick={() => setActivePhoto(item.image)}
              className={`group relative overflow-hidden rounded-md bg-[#0F172A] border border-[#D4AF37]/20 hover:border-[#D4AF37] transition-all duration-500 cursor-pointer shadow-xl ${item.span}`}
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0F1D]/90 via-[#0A0F1D]/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
              
              {/* Content Overlay */}
              <div className="absolute inset-0 p-6 flex flex-col justify-between">
                <div className="self-end opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="p-2.5 rounded-full bg-[#0A0F1D]/80 border border-[#D4AF37]/60 text-[#D4AF37] inline-flex items-center justify-center">
                    <ZoomIn className="w-4 h-4" />
                  </span>
                </div>

                <div>
                  <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#D4AF37] block mb-1">
                    {item.category}
                  </span>
                  <h3 className="font-heading text-xl sm:text-2xl font-bold text-white group-hover:text-[#F3E5AB] transition-colors">
                    {item.title}
                  </h3>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {activePhoto && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setActivePhoto(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh] rounded-md overflow-hidden border border-[#D4AF37]/50 shadow-2xl">
            <img
              src={activePhoto}
              alt="Ampliação da barbearia LP Cortes"
              className="w-full h-auto max-h-[85vh] object-contain"
            />
            <button
              onClick={() => setActivePhoto(null)}
              className="absolute top-4 right-4 text-white bg-black/60 rounded-full p-2 border border-slate-600 hover:border-[#D4AF37] text-xs font-bold"
            >
              Fechar ✕
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
