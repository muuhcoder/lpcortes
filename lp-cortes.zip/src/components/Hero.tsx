import React from 'react';
import { ArrowDown, Calendar, Sparkles, CheckCircle2 } from 'lucide-react';
import { BARBERSHOP_DATA } from '../data/barbershop';

interface HeroProps {
  onOpenBooking: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenBooking }) => {
  return (
    <section
      id="inicio"
      className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center pt-24 pb-16 lg:pt-28 lg:pb-20 overflow-hidden"
    >
      {/* Background radial atmosphere */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] bg-[#D4AF37]/8 rounded-full blur-[140px]" />
        <div className="absolute bottom-10 right-10 w-[450px] h-[450px] bg-[#0F172A] rounded-full blur-[100px] border border-[#D4AF37]/5" />
        {/* Subtle grid texture overlay */}
        <div 
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #D4AF37 1px, transparent 0)`,
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Bold Typography & Slogan */}
          <div className="lg:col-span-7 flex flex-col justify-center text-left">
            
            {/* Elegant Pill Badge */}
            <div className="inline-flex items-center gap-2 self-start px-3.5 py-1.5 mb-6 rounded-full border border-[#D4AF37]/40 bg-[#0F172A]/90 backdrop-blur-sm shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span className="text-[11px] font-semibold tracking-[0.25em] uppercase text-[#D4AF37]">
                Barbearia Clássica & Moderna
              </span>
            </div>

            {/* Giant Confident Headline */}
            <h1 className="font-heading text-5xl sm:text-6xl md:text-7xl xl:text-[5.25rem] font-bold text-white tracking-tight leading-[1.04] mb-6">
              Estilo & <br />
              <span className="text-gold-gradient relative inline-block">
                Tradição
                <span className="absolute -bottom-2 left-0 right-0 h-[2px] bg-gradient-to-r from-[#D4AF37] via-[#F3E5AB] to-transparent opacity-80" />
              </span>
            </h1>

            {/* Slogan - strictly <= 8 words, bold & magnetic */}
            <p className="text-xl sm:text-2xl text-[#E2E8F0] font-light tracking-wide mb-4">
              Precisão que define sua presença.
            </p>

            {/* Supporting single sentence */}
            <p className="text-sm sm:text-base text-slate-400 font-normal leading-relaxed max-w-xl mb-10">
              O ponto de encontro entre a precisão da navalha clássica e as tendências contemporâneas no coração de Birigui.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 sm:gap-5 mb-10">
              <button
                onClick={onOpenBooking}
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 text-sm font-bold tracking-wider uppercase text-[#0F172A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89228] hover:from-white hover:via-[#F3E5AB] hover:to-[#D4AF37] rounded-sm transition-all duration-300 shadow-xl shadow-[#D4AF37]/25 hover:shadow-2xl hover:shadow-[#D4AF37]/40 hover:-translate-y-0.5 cursor-pointer"
              >
                <Calendar className="w-4 h-4 text-[#0F172A] transition-transform group-hover:scale-110" />
                <span>Agende seu Horário</span>
              </button>

              <a
                href="#servicos"
                className="inline-flex items-center justify-center gap-2 px-7 py-4 text-sm font-semibold tracking-wide text-slate-200 hover:text-white bg-[#0F172A]/70 hover:bg-[#162035] border border-[#D4AF37]/40 hover:border-[#D4AF37] rounded-sm transition-all duration-300"
              >
                <span>Conhecer Serviços</span>
              </a>
            </div>

            {/* Micro Highlights */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-6 border-t border-slate-800/80">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="text-xs text-slate-300">Toalha Quente</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="text-xs text-slate-300">Visagismo Facial</span>
              </div>
              <div className="flex items-center gap-2 col-span-2 sm:col-span-1">
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span className="text-xs text-slate-300">Cerveja & Café Cortesia</span>
              </div>
            </div>

          </div>

          {/* Right Column: Hero Real Barbershop Image with Editorial Framing */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Outer decorative frame border */}
              <div className="absolute -inset-3 rounded-md border border-[#D4AF37]/30 -z-10 translate-x-2 translate-y-2 hidden sm:block" />
              
              {/* Main photo container */}
              <div className="relative rounded-md overflow-hidden bg-[#0F172A] border border-[#D4AF37]/50 shadow-2xl shadow-black/80 aspect-[4/5] group">
                <img
                  src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=1200&q=85"
                  alt="Interior luxuoso da barbearia LP Cortes com cadeira de couro vintage e iluminação quente"
                  className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-700 ease-out"
                  loading="eager"
                  fetchPriority="high"
                />
                
                {/* Vignette & Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0F1D] via-transparent to-transparent opacity-80" />
                
                {/* Floating Tag on Image */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-sm bg-[#0A0F1D]/85 backdrop-blur-md border border-[#D4AF37]/35">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[11px] uppercase tracking-[0.2em] text-[#D4AF37] font-semibold">
                        Espaço Exclusivo
                      </p>
                      <p className="font-heading text-lg font-bold text-white">
                        Atendimento Premium
                      </p>
                    </div>
                    <span className="text-xs font-mono text-slate-400">Birigui • SP</span>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Scroll invitation indicator */}
        <div className="mt-12 lg:mt-16 text-center flex flex-col items-center justify-center">
          <a
            href="#servicos"
            className="group inline-flex flex-col items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-slate-400 hover:text-[#D4AF37] transition-colors"
          >
            <span>Role para conhecer</span>
            <div className="w-6 h-10 rounded-full border border-slate-700 group-hover:border-[#D4AF37] flex items-start justify-center p-1 transition-colors">
              <span className="w-1 h-2 bg-[#D4AF37] rounded-full animate-bounce" />
            </div>
          </a>
        </div>

      </div>
    </section>
  );
};
