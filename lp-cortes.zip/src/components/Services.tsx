import React from 'react';
import { Clock, Check, ArrowRight, Sparkles, Scissors } from 'lucide-react';
import { BARBERSHOP_DATA, ServiceItem } from '../data/barbershop';

interface ServicesProps {
  onOpenBooking: (serviceId?: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ onOpenBooking }) => {
  // Primary 3 services from the brief + combo
  const primaryServices = BARBERSHOP_DATA.services;

  return (
    <section id="servicos" className="py-24 sm:py-32 relative bg-[#0B1020] border-t border-[#D4AF37]/15">
      
      {/* Background glow accents */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#D4AF37]/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-[#0F172A] rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-[#D4AF37]/40 bg-[#0F172A] mb-4">
            <Scissors className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span className="text-xs font-semibold tracking-[0.2em] uppercase text-[#D4AF37]">
              Menu de Experiências
            </span>
          </div>

          <h2 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight mb-4">
            Nossos Serviços
          </h2>

          <p className="text-base sm:text-lg text-slate-400 font-light">
            Procedimentos executados com lâminas de precisão, toalha aquecida e produtos de alta performance.
          </p>
        </div>

        {/* 3 Main Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {primaryServices.slice(0, 3).map((service) => (
            <div
              key={service.id}
              className="group relative flex flex-col rounded-md overflow-hidden bg-[#0F172A] border border-[#D4AF37]/25 hover:border-[#D4AF37] transition-all duration-500 shadow-xl shadow-black/40 hover:-translate-y-1.5"
            >
              {/* Photo */}
              <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-slate-900">
                <img
                  src={service.image}
                  alt={`Serviço de barbearia: ${service.name}`}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F172A] via-[#0F172A]/40 to-transparent" />
                
                {/* Duration badge */}
                <div className="absolute top-4 right-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0A0F1D]/80 backdrop-blur-md border border-slate-700/60 text-xs font-medium text-slate-300">
                  <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>{service.duration}</span>
                </div>

                {/* Category tag */}
                <div className="absolute bottom-3 left-5">
                  <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#D4AF37]">
                    {service.category}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-7 flex flex-col flex-1 justify-between">
                <div>
                  <div className="flex items-baseline justify-between gap-4 mb-3">
                    <h3 className="font-heading text-2xl font-bold text-white group-hover:text-[#D4AF37] transition-colors">
                      {service.name}
                    </h3>
                    <div className="text-right">
                      <span className="text-xs text-slate-400 uppercase tracking-wider block">Valor</span>
                      <span className="font-heading text-2xl font-extrabold text-[#D4AF37]">
                        R$ {service.price}
                      </span>
                    </div>
                  </div>

                  <p className="text-sm text-slate-300/90 leading-relaxed mb-6 font-normal">
                    {service.description}
                  </p>
                </div>

                {/* Action button */}
                <button
                  onClick={() => onOpenBooking(service.id)}
                  className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-bold uppercase tracking-wider text-slate-200 hover:text-[#0F172A] bg-[#141C30] hover:bg-[#D4AF37] border border-[#D4AF37]/40 hover:border-[#D4AF37] rounded-sm transition-all duration-300 cursor-pointer"
                >
                  <span>Agendar {service.name}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Featured Combo Banner - High Value Offer */}
        <div className="relative rounded-md overflow-hidden bg-gradient-to-r from-[#121A2E] via-[#0F172A] to-[#172138] border border-[#D4AF37]/60 p-6 sm:p-10 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 mb-3">
                <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span className="text-[11px] font-bold uppercase tracking-widest text-[#D4AF37]">
                  Mais Escolhido • Experiência Completa
                </span>
              </div>
              <h3 className="font-heading text-3xl sm:text-4xl font-bold text-white mb-2">
                Combo LP Signature (Corte + Barba)
              </h3>
              <p className="text-slate-300 text-sm sm:text-base max-w-2xl font-light">
                O combo definitivo para renovar totalmente seu visual: corte estilizado com navalha e tesoura mais o ritual completo de barba terapia com toalha aromática aquecida.
              </p>
            </div>

            <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col items-start lg:items-end justify-between gap-4">
              <div className="text-left lg:text-right">
                <div className="text-xs text-slate-400 line-through">De R$ 105,00</div>
                <div className="font-heading text-3xl sm:text-4xl font-black text-[#D4AF37]">
                  R$ 95,00
                </div>
                <div className="text-xs text-slate-400">Economia e conveniência</div>
              </div>

              <button
                onClick={() => onOpenBooking('combo-lp')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-[#0F172A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89228] hover:from-white hover:to-[#D4AF37] rounded-sm transition-all duration-300 shadow-lg shadow-[#D4AF37]/20 cursor-pointer"
              >
                <span>Agendar Combo Completo</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
