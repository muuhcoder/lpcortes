import React from 'react';
import { BARBERSHOP_DATA } from '../data/barbershop';
import { Phone, MapPin, Scissors, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#070A14] border-t border-[#D4AF37]/20 pt-16 pb-12 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800">
          
          {/* Brand Col */}
          <div className="lg:col-span-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-sm border border-[#D4AF37] bg-[#0F172A] flex items-center justify-center">
                <span className="font-heading text-base font-bold text-[#D4AF37]">LP</span>
              </div>
              <span className="font-heading text-xl font-bold tracking-widest text-white uppercase">
                LP Cortes
              </span>
            </div>
            <p className="text-sm text-slate-400 max-w-sm mb-6 leading-relaxed">
              Barbearia premium em Birigui. Cortes masculinos de alta precisão, barboterapia tradicional e rituais capilares exclusivos.
            </p>
            <div className="text-xs text-[#D4AF37] tracking-widest uppercase font-semibold">
              Estilo & Tradição • Desde 2011
            </div>
          </div>

          {/* Navigation Links */}
          <div className="lg:col-span-3">
            <h4 className="font-heading text-sm font-bold uppercase tracking-widest text-white mb-4">
              Navegação
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a href="#inicio" className="hover:text-[#D4AF37] transition-colors">Início</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Serviços & Preços</a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-[#D4AF37] transition-colors">Sobre a Tradição</a>
              </li>
              <li>
                <a href="#galeria" className="hover:text-[#D4AF37] transition-colors">Galeria de Estilos</a>
              </li>
              <li>
                <a href="#contato" className="hover:text-[#D4AF37] transition-colors">Localização & Contato</a>
              </li>
            </ul>
          </div>

          {/* Quick Contact */}
          <div className="lg:col-span-4">
            <h4 className="font-heading text-sm font-bold uppercase tracking-widest text-white mb-4">
              LP Cortes Birigui
            </h4>
            <div className="space-y-3 text-sm text-slate-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{BARBERSHOP_DATA.address.full}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <a 
                  href={`tel:${BARBERSHOP_DATA.phone.raw}`}
                  className="hover:text-[#D4AF37] transition-colors"
                >
                  {BARBERSHOP_DATA.phone.display}
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom copyright and project download */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} LP Cortes Barbearia. Todos os direitos reservados.</p>
          <div className="flex items-center gap-4">
            <a
              href="/lp-cortes.zip"
              download="lp-cortes.zip"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#0F172A] border border-[#D4AF37]/40 text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0F172A] transition-all font-semibold"
              title="Baixar pacote completo do projeto em .ZIP"
            >
              <span>Baixar Projeto (.ZIP)</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
