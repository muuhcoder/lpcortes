import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, User, Check, Scissors, Phone, MessageSquare } from 'lucide-react';
import { BARBERSHOP_DATA, ServiceItem } from '../data/barbershop';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedServiceId?: string;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  preselectedServiceId
}) => {
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [selectedBarber, setSelectedBarber] = useState<string>('qualquer');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('14:00');
  const [clientName, setClientName] = useState<string>('');
  const [clientPhone, setClientPhone] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Pre-fill initial selection when opening
  useEffect(() => {
    if (preselectedServiceId) {
      setSelectedServices([preselectedServiceId]);
    } else if (selectedServices.length === 0) {
      setSelectedServices(['corte-masculino']);
    }

    // Default date to tomorrow if empty
    if (!selectedDate) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setSelectedDate(tomorrow.toISOString().split('T')[0]);
    }
  }, [preselectedServiceId, isOpen]);

  if (!isOpen) return null;

  const toggleService = (id: string) => {
    if (selectedServices.includes(id)) {
      if (selectedServices.length > 1) {
        setSelectedServices(selectedServices.filter(s => s !== id));
      }
    } else {
      setSelectedServices([...selectedServices, id]);
    }
  };

  // Calculate total price
  const totalPrice = selectedServices.reduce((sum, serviceId) => {
    const s = BARBERSHOP_DATA.services.find(item => item.id === serviceId);
    return sum + (s ? s.price : 0);
  }, 0);

  // Time slots
  const timeSlots = [
    '09:00', '10:00', '11:00', '13:30', '14:30', '15:30', '16:30', '17:30', '18:30', '19:00'
  ];

  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim()) {
      setErrorMsg('Por favor, informe seu nome para o agendamento.');
      return;
    }

    setErrorMsg('');

    // Format selected services names
    const serviceNames = selectedServices
      .map(id => BARBERSHOP_DATA.services.find(s => s.id === id)?.name)
      .filter(Boolean)
      .join(' + ');

    const barberName = selectedBarber === 'qualquer' 
      ? 'Primeiro barbeiro disponível' 
      : BARBERSHOP_DATA.barbers.find(b => b.id === selectedBarber)?.name || selectedBarber;

    // Format date in PT-BR
    const dateFormatted = selectedDate.split('-').reverse().join('/');

    const message = `*NOVO AGENDAMENTO - LP CORTES*\n\n` +
      `👤 *Cliente:* ${clientName.trim()}\n` +
      `📱 *Telefone:* ${clientPhone.trim() || 'Não informado'}\n` +
      `✂️ *Serviço(s):* ${serviceNames}\n` +
      `💰 *Valor Estimado:* R$ ${totalPrice},00\n` +
      `💈 *Barbeiro:* ${barberName}\n` +
      `📅 *Data:* ${dateFormatted}\n` +
      `⏰ *Horário desejado:* ${selectedTime}\n` +
      (notes.trim() ? `📝 *Observação:* ${notes.trim()}\n\n` : '\n') +
      `Olá! Gostaria de confirmar a disponibilidade deste horário na LP Cortes.`;

    const encoded = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${BARBERSHOP_DATA.phone.raw}?text=${encoded}`;
    
    // Open in new tab
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4">
      <div 
        className="relative w-full max-w-2xl bg-[#0F172A] border border-[#D4AF37]/50 rounded-md shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#D4AF37]/25 bg-[#0A0F1D]/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-[#D4AF37]/10 border border-[#D4AF37]/30 text-[#D4AF37]">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-heading text-xl font-bold text-white">
                Agendamento Online
              </h3>
              <p className="text-xs text-slate-400">
                Selecione seus serviços e confirme instantaneamente no WhatsApp
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-slate-800/60 transition-colors"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleConfirmBooking} className="p-6 space-y-6">
          
          {errorMsg && (
            <div className="p-3 text-xs bg-red-950/60 border border-red-500/50 text-red-200 rounded">
              {errorMsg}
            </div>
          )}

          {/* 1. Escolha de Serviços */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#D4AF37] mb-3">
              1. Escolha o(s) Serviço(s)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {BARBERSHOP_DATA.services.map((service) => {
                const isSelected = selectedServices.includes(service.id);
                return (
                  <button
                    key={service.id}
                    type="button"
                    onClick={() => toggleService(service.id)}
                    className={`flex items-center justify-between p-3.5 rounded border text-left transition-all ${
                      isSelected
                        ? 'bg-[#17233D] border-[#D4AF37] shadow-sm shadow-[#D4AF37]/20 text-white'
                        : 'bg-[#0B1020] border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="pr-2">
                      <div className="text-sm font-semibold flex items-center gap-2">
                        <span>{service.name}</span>
                        {service.popular && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#D4AF37]/20 text-[#D4AF37] font-bold">
                            TOP
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400">{service.duration}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-[#D4AF37]">
                        R$ {service.price}
                      </span>
                      <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        isSelected ? 'border-[#D4AF37] bg-[#D4AF37] text-[#0F172A]' : 'border-slate-600'
                      }`}>
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Preferência de Barbeiro */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#D4AF37] mb-2">
              2. Preferência de Barbeiro
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setSelectedBarber('qualquer')}
                className={`p-2.5 rounded text-xs font-medium border text-center transition-all ${
                  selectedBarber === 'qualquer'
                    ? 'bg-[#17233D] border-[#D4AF37] text-white font-bold'
                    : 'bg-[#0B1020] border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                Qualquer Barbeiro
              </button>
              {BARBERSHOP_DATA.barbers.map((b) => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setSelectedBarber(b.id)}
                  className={`p-2.5 rounded text-xs font-medium border text-center transition-all ${
                    selectedBarber === b.id
                      ? 'bg-[#17233D] border-[#D4AF37] text-white font-bold'
                      : 'bg-[#0B1020] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {b.name}
                </button>
              ))}
            </div>
          </div>

          {/* 3. Data e Horário */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#D4AF37] mb-2">
                3. Data Pretendida
              </label>
              <input
                type="date"
                value={selectedDate}
                min={new Date().toISOString().split('T')[0]}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded bg-[#0B1020] border border-slate-700 text-white text-sm focus:border-[#D4AF37] focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#D4AF37] mb-2">
                Horário Sugerido
              </label>
              <select
                value={selectedTime}
                onChange={(e) => setSelectedTime(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded bg-[#0B1020] border border-slate-700 text-white text-sm focus:border-[#D4AF37] focus:outline-none"
              >
                {timeSlots.map((time) => (
                  <option key={time} value={time}>
                    {time} horas
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 4. Dados do Cliente */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#D4AF37] mb-1.5">
                Seu Nome Completo *
              </label>
              <input
                type="text"
                placeholder="Ex.: Carlos Silva"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded bg-[#0B1020] border border-slate-700 text-white placeholder-slate-500 text-sm focus:border-[#D4AF37] focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-[#D4AF37] mb-1.5">
                Seu WhatsApp / Telefone
              </label>
              <input
                type="tel"
                placeholder="(18) 99999-9999"
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded bg-[#0B1020] border border-slate-700 text-white placeholder-slate-500 text-sm focus:border-[#D4AF37] focus:outline-none"
              />
            </div>
          </div>

          {/* Total & Submit */}
          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-400 block">Total Estimado</span>
              <span className="font-heading text-3xl font-black text-[#D4AF37]">
                R$ {totalPrice},00
              </span>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 text-xs font-bold uppercase tracking-wider text-[#0F172A] bg-gradient-to-r from-[#F3E5AB] via-[#D4AF37] to-[#B89228] hover:from-white hover:to-[#D4AF37] rounded-sm transition-all duration-300 shadow-xl shadow-[#D4AF37]/20 cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 fill-[#0F172A]" />
              <span>Confirmar no WhatsApp</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
