export interface ServiceItem {
  id: string;
  name: string;
  category: string;
  price: number;
  duration: string;
  description: string;
  image: string;
  popular?: boolean;
}

export interface Barber {
  id: string;
  name: string;
  role: string;
  specialty: string;
  avatar: string;
}

export const BARBERSHOP_DATA = {
  name: "LP Cortes",
  tagline: "Precisão que define sua presença.",
  establishedYear: 2011,
  address: {
    street: "R. Palmiro Boato, 110",
    neighborhood: "Quemil",
    city: "Birigui",
    state: "SP",
    zip: "16202-260",
    full: "R. Palmiro Boato, 110 - Quemil, Birigui - SP, 16202-260",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=R.+Palmiro+Boato,+110+-+Quemil,+Birigui+-+SP,+16202-260"
  },
  phone: {
    raw: "5518988019075",
    display: "(18) 98801-9075",
    whatsappUrl: "https://wa.me/5518988019075?text=Ol%C3%A1%2C%20gostaria%20de%20agendar%20um%20hor%C3%A1rio%20na%20LP%20Cortes."
  },
  hours: [
    { days: "Terça a Sexta", time: "09:00 às 20:00" },
    { days: "Sábado", time: "08:30 às 19:30" },
    { days: "Domingo e Segunda", time: "Fechado para recarga" }
  ],
  stats: [
    { value: "15+", label: "Anos de Experiência", detail: "Mestres da navalha clássica" },
    { value: "10.000+", label: "Clientes Atendidos", detail: "Em Birigui e região" },
    { value: "5", label: "Barbeiros Especialistas", detail: "Formação de alto nível" },
    { value: "4.9", label: "Nota de Avaliação", detail: "Excelência comprovada" }
  ],
  services: [
    {
      id: "corte-masculino",
      name: "Corte Masculino",
      category: "Cabelo & Visagismo",
      price: 60,
      duration: "45 min",
      description: "Design contemporâneo ou clássico personalizado ao formato do seu rosto, finalizado com lavagem refrescante e pomada matte premium.",
      image: "https://images.unsplash.com/photo-1622286342621-4bd786c2447c?auto=format&fit=crop&w=900&q=80",
      popular: true
    },
    {
      id: "barba",
      name: "Barba Terapia",
      category: "Barboterapia",
      price: 45,
      duration: "35 min",
      description: "Ritual completo com toalha quente aromática, navalhete de alta precisão, alinhamento simétrico e hidratação com óleos nobres.",
      image: "https://images.unsplash.com/photo-1517832606299-7ae9b720a186?auto=format&fit=crop&w=900&q=80",
      popular: false
    },
    {
      id: "tratamento-capilar",
      name: "Tratamento Capilar",
      category: "Saúde do Couro",
      price: 80,
      duration: "40 min",
      description: "Terapia revitalizante profunda com esfoliação do couro cabeludo, nutrição capilar intensiva e massagem craniana relaxante.",
      image: "https://images.unsplash.com/photo-1585747860715-2ba37e788b70?auto=format&fit=crop&w=900&q=80",
      popular: false
    },
    {
      id: "combo-lp",
      name: "Combo LP Signature",
      category: "Experiência Completa",
      price: 95,
      duration: "1h 15min",
      description: "A dobradinha perfeita: Corte Masculino completo aliado ao ritual de Barba Terapia com toalha quente e finalização refinada.",
      image: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=900&q=80",
      popular: true
    }
  ],
  barbers: [
    {
      id: "murilo",
      name: "Murilo LP",
      role: "Fundador & Master Barber",
      specialty: "Visagismo e navalha clássica",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "felipe",
      name: "Felipe Andrade",
      role: "Senior Barber",
      specialty: "Fade cirúrgico e tesoura",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80"
    },
    {
      id: "lucas",
      name: "Lucas Ramos",
      role: "Especialista em Barboterapia",
      specialty: "Alinhamento e massagem capilar",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80"
    }
  ],
  gallery: [
    {
      title: "Fade Milimétrico na Tesoura",
      subtitle: "Degradê suave e acabamento limpo",
      image: "https://images.unsplash.com/photo-1599351431202-1e0f0137899a?auto=format&fit=crop&w=900&q=80",
      aspect: "tall"
    },
    {
      title: "Ritual Tradicional da Navalha",
      subtitle: "Toalha quente e alinhamento artesanal",
      image: "https://images.unsplash.com/photo-1621605815971-fbc98d665033?auto=format&fit=crop&w=900&q=80",
      aspect: "wide"
    },
    {
      title: "Bancada de Mestres Barbeiros",
      subtitle: "Equipamentos esterilizados de alto padrão",
      image: "https://images.unsplash.com/photo-1532710093739-9470acff878f?auto=format&fit=crop&w=900&q=80",
      aspect: "square"
    },
    {
      title: "Ambiente Vintage & Conforto",
      subtitle: "Cadeiras hidráulicas de couro legítimo",
      image: "https://images.unsplash.com/photo-1512690459411-b9245aed614b?auto=format&fit=crop&w=900&q=80",
      aspect: "wide"
    }
  ],
  testimonials: [
    {
      name: "Guilherme Siqueira",
      city: "Birigui - SP",
      comment: "Melhor barbearia de Birigui sem sombra de dúvidas. O cuidado com a barba na toalha quente é um diferencial absurdo. Atendimento nota 10.",
      stars: 5,
      date: "Há 2 semanas"
    },
    {
      name: "Rafael Martins",
      city: "Birigui - SP",
      comment: "Ambiente impecável, café de qualidade e o Murilo tem uma precisão na tesoura que nunca vi igual. Sou cliente há mais de 4 anos.",
      stars: 5,
      date: "Há 1 mês"
    },
    {
      name: "Thiago Brandão",
      city: "Araçatuba / Birigui",
      comment: "Vale cada quilômetro. O tratamento capilar restaurou meu couro cabeludo e o fade ficou perfeito. Recomendo para todo homem exigente.",
      stars: 5,
      date: "Há 3 semanas"
    }
  ],
  faqs: [
    {
      q: "Preciso agendar com antecedência?",
      a: "Recomendamos fortemente o agendamento prévio para garantir pontualidade e o tempo exclusivo de atendimento. Porém, atendemos por ordem de chegada havendo vaga disponível."
    },
    {
      q: "Quais são as formas de pagamento aceitas?",
      a: "Aceitamos Pix, cartões de crédito e débito de todas as bandeiras (com opção de aproximação) e dinheiro em espécie."
    },
    {
      q: "Como funciona a Barba Terapia?",
      a: "É uma experiência sensorial que inclui higienização, toalha aquecida com óleos essenciais para abrir os poros, corte com navalhete descartável novo e loção pós-barba calmante."
    },
    {
      q: "Há estacionamento no local?",
      a: "Sim, há facilidade de estacionamento em frente à barbearia na R. Palmiro Boato, com tranquilidade e segurança."
    }
  ]
};
