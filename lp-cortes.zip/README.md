# LP Cortes — Barbearia Premium

Landing page profissional desenvolvida para a barbearia LP Cortes (Birigui - SP).

## 🚀 Como Executar Localmente

### Pré-requisitos
- Node.js 18+ ou 20+
- npm ou yarn ou pnpm

### Passo a Passo

1. Extraia o arquivo `.zip` em sua pasta de preferência.
2. Abra o terminal na pasta do projeto e instale as dependências:
   ```bash
   npm install
   ```
3. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
4. Acesse no navegador:
   ```
   http://localhost:3000
   ```

### 📦 Como Gerar o Build de Produção
```bash
npm run build
```
Os arquivos otimizados para produção serão gerados na pasta `dist/`.

---

## 🎨 Tecnologias Utilizadas
- **React 19** + **TypeScript**
- **Tailwind CSS v4**
- **Lucide React** (Ícones modernos)
- **Google Fonts** (Playfair Display & Raleway)
- **Vite**
